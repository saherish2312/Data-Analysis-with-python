# fcc-data-analysis-with-python
## Context
My 5 Data Analysis projects that I've built as part of my freeCodeCamp assignment.
<br>
## Overview
The course notebooks and building these projects allowed me to obtain new skills and familiarize myself more with the Python's Data Analysis and visualization toolbox.
I learned the whole process of Data Analysis: reading data from multiple sources (CSVs, SQL, Excel, etc), processing them using NumPy and Pandas, visualize them using Matplotlib and Seaborn and clean and process it to create reports.
## Certification
These projects also allowed me to obtain my <a href="https://www.freecodecamp.org/certification/ilyas-moutawwakil/data-analysis-with-python-v7">Data Analysis with Python Certification</a> which is a Developer Certification, representing approximately 400 hours of coursework.
